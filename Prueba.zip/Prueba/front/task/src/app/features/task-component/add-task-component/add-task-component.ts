import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { TaskService } from '../../../core/services/task/task-service';

@Component({
  selector: 'app-add-task-component',
  imports: [MatFormFieldModule, CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule],
  templateUrl: './add-task-component.html',
  styleUrl: './add-task-component.css'
})
export class AddTaskComponent implements OnInit {

  taskForm!: FormGroup;
  isEditMode = false;

  constructor(private fb: FormBuilder,
    private dialogRef: MatDialogRef<AddTaskComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private taskService: TaskService) {
      console.log(data);
      
    !data ? this.isEditMode = false : this.isEditMode = true

  }



  ngOnInit() {
    this.taskForm = this.fb.group({
      task: [this.data?.task.task || '', [Validators.required, Validators.minLength(3)]],
    });
  }

  save() {
    if (!this.isEditMode) {
      if (this.taskForm.valid) {
        console.log(this.taskForm.value);
        this.taskService.postTask(this.taskForm.value).subscribe({
          next: () => {
            this.dialogRef.close(this.taskForm.value);
          },
          error: (err) => console.error(err)
        });
      }
    }else{
      console.log("yo");
      
      if (this.taskForm.valid) {
        console.log(this.taskForm.value);
        this.taskService.updateTask(this.data.task.id,this.taskForm.value).subscribe({
          next: () => {
            this.dialogRef.close(this.taskForm.value);
          },
          error: (err) => console.error(err)
        });
      }

    }

  }

  close() {
    this.dialogRef.close();
  }

}
