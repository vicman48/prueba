import { ChangeDetectorRef, Component, Inject, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { TaskService } from '../../core/services/task/task-service';
import { task } from '../../core/models/task';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AddTaskComponent } from './add-task-component/add-task-component';

@Component({
  selector: 'app-task-component',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatDialogModule,
    MatInputModule,
    MatFormFieldModule,],
  templateUrl: './task-component.html',
  styleUrl: './task-component.css'
})
export class TaskComponent implements OnInit {

  listTask: Array<task> = [];
  form!: FormGroup
  @ViewChild('confirmDialog') confirmDialog!: TemplateRef<any>;
  private dialogRef!: MatDialogRef<any>;

  constructor(public taskService: TaskService,
    private dialog: MatDialog,
    private cdRef: ChangeDetectorRef) {

  }
  ngOnInit(): void {
    this.getTask()
  }

  getTask() {
    this.taskService.getTask().subscribe({
      next: (value: task[]) => {
        console.log(value)
        this.listTask = value;
        this.cdRef.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }


  openAddModal(taskToEdit?: any) {
    const dialogRef = this.dialog.open(AddTaskComponent, {
      width: '50%',
      data: taskToEdit ? { task: taskToEdit } : null,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log("entre");

        this.getTask()
      }
    });
  }


  openConfirmDialog(item: any) {

    this.dialogRef = this.dialog.open(this.confirmDialog);

    this.dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.taskService.deleteTask(item.id).subscribe({
          next: () => this.getTask(), 
          error: (err) => console.error(err)
        });

      }
    });
  }

  closeDialog(result: boolean) {
    if (this.dialogRef) {
      this.dialogRef.close(result);
    }
  }

}
