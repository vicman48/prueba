import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { task } from '../../models/task';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private http: HttpClient) { }

  getTask(): Observable<task[]> {
    return this.http.get<task[]>('http://localhost:5000/tasks/')
  }

  postTask(data: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post<any>('http://localhost:5000/tasks/', data, { headers });
  }

  updateTask(id: number, data: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.put<any>(`http://localhost:5000/tasks/${id}`, data, { headers });
  }

  deleteTask(id: number): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    console.log("entre");
    
    return this.http.delete<any>(`http://localhost:5000/tasks/${id}`, { headers });
  }

}
