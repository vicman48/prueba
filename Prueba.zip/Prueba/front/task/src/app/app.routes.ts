import { Routes } from '@angular/router';

export const routes: Routes = [
    {
    path: 'task',
    loadChildren: () => import('./features/admin.routes').then(m => m.TASK_ROUTES)
  },
  { path: '', redirectTo: '/task', pathMatch: 'full' },

];
