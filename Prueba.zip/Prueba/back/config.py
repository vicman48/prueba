class Config:
    API_TITLE = "Task API"
    API_VERSION = "v1"
    OPENAPI_VERSION = "3.0.3"
    SQLALCHEMY_DATABASE_URI = "sqlite:///tasks.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
