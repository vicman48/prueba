from flask import Flask
from flask_smorest import Api
from config import Config
from db.db import db
from models import task_model
from resources.task_resource import blp as TaskBlueprint
from flask_cors import CORS

app = Flask(__name__)
CORS(app, origins=['http://localhost:4200'])
app.config.from_object(Config)

db.init_app(app)
api = Api(app)
api.register_blueprint(TaskBlueprint)

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True)
