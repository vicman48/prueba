from flask.views import MethodView
from flask_smorest import Blueprint, abort
from db.db import db
from models.task_model import TaskModel
from schemas.task_schema import TaskSchema

blp = Blueprint("Tasks", "tasks", url_prefix="/tasks", description="Task operations")

@blp.route("/")
class TaskList(MethodView):
    @blp.response(200, TaskSchema(many=True))
    def get(self):
        return TaskModel.query.all()

    @blp.arguments(TaskSchema)
    @blp.response(201, TaskSchema)
    def post(self, task_data):
        task = task_data
        db.session.add(task)
        db.session.commit()
        return task

@blp.route("/<int:task_id>")
class TaskResource(MethodView):
    @blp.response(200, TaskSchema)
    def get(self, task_id):
        return TaskModel.query.get_or_404(task_id)

    @blp.arguments(TaskSchema)
    @blp.response(200, TaskSchema)
    def put(self, task_data, task_id):
        task = TaskModel.query.get_or_404(task_id)
        task.task = task_data.task
        db.session.commit()
        return task

    def delete(self, task_id):
        print(f"Delete request received for id: {task_id}")
        task = TaskModel.query.get_or_404(task_id)
        db.session.delete(task)
        db.session.commit()
        print(f"Task with id {task_id} deleted successfully.")
        return {"message": "Task deleted"}, 200
