from marshmallow_sqlalchemy import SQLAlchemyAutoSchema
from models.task_model import TaskModel
from db.db import db

class TaskSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = TaskModel
        load_instance = True
        sqla_session = db.session 
